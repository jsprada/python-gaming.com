<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */

$l['mybb_credits'] = "MyBB Credits";
$l['mybb_credits_description'] = "These people have contributed their time and effort to create MyBB.";
$l['about_the_team'] = "About the Team";
$l['check_for_updates'] = "Check for Updates";
$l['error_communication'] = "There was a problem downloading the latest credits. Please try again in a few minutes.";
$l['no_credits'] = "No stored MyBB credits. <a href=\"index.php?module=home-credits&amp;fetch_new=1\">Check for Updates</a>.";
$l['success_credits_updated'] = 'The MyBB credits cache has been successfully updated.';
