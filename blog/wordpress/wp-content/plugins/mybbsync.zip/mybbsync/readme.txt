=== Plugin Name ===
Contributors: pctricks.ir
Donate link: http://donate.shiraali.com/
Tags: mybb, mybb users,mybbSync
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 4.3
License: You Can Not Change or Sell.
License URI: http://ctboard.com

This Plugin Sync Wordpress User With Mybb.
== Description ==
 *After Login user in Wordpress System User Add to Mybb System automatically

== Installation ==

1. Upload plugin From wordpress admin and Active it.
2. Go to Setting >> Mybb Sync and Set options

== Frequently Asked Questions ==
<a href="http://forum.ctboard.com" rel="follow" >Community</a>


== Screenshots ==

1. options.png



